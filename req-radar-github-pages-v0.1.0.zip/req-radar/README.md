# ReqRadar

ReqRadar is a browser-based recruiting workspace for uploading, analyzing, comparing, and tracking job requisitions.

## Live site

After the GitHub Pages workflow completes:

`https://jmhm-intuit.github.io/req-radar/`

## Version

The current version is displayed permanently at the bottom of the application sidebar.

**ReqRadar v0.1.0**

The UI reads the version from `package.json` during the Vite build.

## Included in v0.1.0

- Upload PDF and TXT job postings.
- Paste a job description directly into the app.
- Extract common requisition fields in the browser.
- Check exact duplicates by Job ID and SHA-256 source fingerprint.
- Compare titles, skills, category, team, hiring manager, seniority, and location.
- Track New, Pursuing, Maybe, Not pursuing, and Applied statuses.
- Search, filter, edit notes, and delete requisitions.
- Export and import a JSON backup.
- Optional fictional demo portfolio.
- Responsive layout for phones and computers.
- Automatic deployment to GitHub Pages with GitHub Actions.

## Privacy and storage

This GitHub Pages version has no backend. PDF parsing and duplicate checks run in the browser. Requisition data is saved in `localStorage` for the current browser profile.

The original uploaded PDF is not stored. ReqRadar keeps the extracted text, metadata, file name, and SHA-256 fingerprint. Use **Export backup** to move data between devices or browsers.

Do not add confidential job files to the public GitHub repository. Upload them only through the running app, where they are processed locally.

## GitHub Pages setup

The repository must use **Settings > Pages > Source: GitHub Actions**. The included workflow builds the Vite site and publishes the `dist` directory after each push to `main`.

The Vite production base path is `/req-radar/`, which matches the repository URL.

## Local development

Requirements:

- Node.js 20 or newer
- npm

Install and run:

```bash
npm install
npm run dev
```

Open the URL printed by Vite, normally `http://localhost:5173/`.

Create a production build:

```bash
npm run build
npm run preview
```

## Updating the version

Change the `version` field in `package.json`, for example:

```json
{
  "version": "0.1.1"
}
```

Commit and push. The next GitHub Pages build will display the new version automatically.

## Limitations of the static version

- Data is not synchronized between devices unless you export and import a backup.
- There is no authentication or shared database.
- There are no secure server-side AI calls.
- Scanned PDFs require OCR, which is not included in this release.
- Field extraction is rules-based and should be reviewed before saving.
