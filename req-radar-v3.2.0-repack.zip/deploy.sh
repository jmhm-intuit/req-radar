#!/usr/bin/env bash
set -Eeuo pipefail

ZIP_PATH="${1:-req-radar-v3.2.0-repack.zip}"
ZIP_NAME="$(basename "$ZIP_PATH")"
TMP="/tmp/req-radar-v3-2-0-deploy"

ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"

if [ ! -f "$ZIP_PATH" ]; then
  echo "ERROR: Deployment ZIP not found: $ZIP_PATH"
  exit 1
fi

rm -rf "$TMP"
mkdir -p "$TMP"
unzip -q -o "$ZIP_PATH" -d "$TMP"

if ! grep -q '"version": "3.2.0"' "$TMP/package.json"; then
  echo "ERROR: Expected ReqRadar version 3.2.0 was not found in package.json."
  exit 1
fi

if [ ! -d "$TMP/src" ] || [ ! -f "$TMP/.github/workflows/deploy-pages.yml" ]; then
  echo "ERROR: Deployment package is incomplete."
  exit 1
fi

rm -f "$TMP/deploy.sh"

find . -mindepth 1 -maxdepth 1 \
  ! -name '.git' \
  ! -name "$ZIP_NAME" \
  -exec rm -rf {} +

cp -a "$TMP"/. .
rm -rf "$TMP"
rm -f "$ZIP_PATH"

echo "Installed application version:"
grep '"version"' package.json | head -1

git add -A
if git diff --cached --quiet; then
  echo "No source changes to commit."
else
  git commit -m "Deploy ReqRadar v3.2.0"
fi

git push origin main

echo ""
echo "ReqRadar v3.2.0 pushed successfully."
echo "Actions: https://github.com/jmhm-intuit/req-radar/actions"
echo "Live app: https://jmhm-intuit.github.io/req-radar/"
